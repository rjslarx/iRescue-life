export type SquareStatus = 'available' | 'reserved' | 'pending_verification' | 'confirmed';

export type PaymentMethod = 'venmo' | 'cashapp' | 'cash';

export interface Square {
  id: number; // 0 to 99
  row: number; // 0 to 9 (Home Team axis)
  col: number; // 0 to 9 (Away Team axis)
  status: SquareStatus;
  ownerName?: string;
  ownerContact?: string;
  paymentMethod?: PaymentMethod;
  paymentNote?: string;
  paidAt?: string;
  reservedAt?: string;
  verifiedAt?: string;
}

export interface TeamConfig {
  name: string;
  short: string;
  primaryColor: string;
  secondaryColor: string;
  city: string;
}

export interface PayoutPercentages {
  q1: number; // e.g., 20
  q2: number; // e.g., 30 (Halftime)
  q3: number; // e.g., 20
  q4: number; // e.g., 30 (Final)
}

export interface PoolSettings {
  poolName: string;
  eventDate: string;
  squarePrice: number; // e.g., 10
  homeTeam: TeamConfig;
  awayTeam: TeamConfig;
  venmoHandle: string; // without @ or with @
  cashAppHandle: string; // without $ or with $
  payoutPercentages: PayoutPercentages;
  numbersLocked: boolean;
  rowNumbers: number[]; // Home team digits 0-9
  colNumbers: number[]; // Away team digits 0-9
  commissionerPin: string; // default "1234"
}

export interface QuarterScore {
  home: number | null;
  away: number | null;
  isComplete: boolean;
}

export interface GameScores {
  q1: QuarterScore;
  q2: QuarterScore;
  q3: QuarterScore;
  q4: QuarterScore;
  currentQuarter: 'pregame' | 'q1' | 'q2' | 'halftime' | 'q3' | 'q4' | 'final';
}

export interface QuarterWinner {
  quarter: 'q1' | 'q2' | 'q3' | 'q4';
  label: string;
  homeDigit: number;
  awayDigit: number;
  squareId: number;
  winnerName: string;
  payoutAmount: number;
  isConfirmed: boolean;
}

export type GridFilter = 'all' | 'available' | 'pending' | 'mine' | 'winners';
