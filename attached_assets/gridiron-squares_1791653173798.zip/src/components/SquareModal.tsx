import React, { useState, useEffect } from 'react';
import { Square, PoolSettings, QuarterWinner } from '../types/pool';
import { X, Trophy, Shield, ArrowRight, User, Mail, DollarSign, RotateCcw, Check } from 'lucide-react';
import { playSquareSelectSound } from '../utils/soundEffects';

interface SquareModalProps {
  square: Square | null;
  settings: PoolSettings;
  isOpen: boolean;
  onClose: () => void;
  onProceedToPayment: (square: Square, claimantData: { name: string; contact: string; note: string }) => void;
  isCommissioner: boolean;
  onApproveSquare?: (squareId: number) => void;
  onReleaseSquare?: (squareId: number) => void;
  quarterWinners: QuarterWinner[];
}

export const SquareModal: React.FC<SquareModalProps> = ({
  square,
  settings,
  isOpen,
  onClose,
  onProceedToPayment,
  isCommissioner,
  onApproveSquare,
  onReleaseSquare,
  quarterWinners,
}) => {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [note, setNote] = useState('');
  const [validationError, setValidationError] = useState('');

  useEffect(() => {
    if (square) {
      playSquareSelectSound();
      // Pre-fill user if available in localStorage
      const savedUser = localStorage.getItem('gridiron_user_name') || '';
      const savedContact = localStorage.getItem('gridiron_user_contact') || '';
      setName(savedUser);
      setContact(savedContact);
      setNote('');
      setValidationError('');
    }
  }, [square]);

  if (!isOpen || !square) return null;

  const rowDigit = settings.numbersLocked ? settings.rowNumbers[square.row] : '?';
  const colDigit = settings.numbersLocked ? settings.colNumbers[square.col] : '?';
  const squareWins = quarterWinners.filter((w) => w.squareId === square.id);

  const handleSubmitClaim = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setValidationError('Please enter your name to claim this square.');
      return;
    }

    // Save user info for convenience
    localStorage.setItem('gridiron_user_name', name.trim());
    if (contact.trim()) {
      localStorage.setItem('gridiron_user_contact', contact.trim());
    }

    onProceedToPayment(square, {
      name: name.trim(),
      contact: contact.trim(),
      note: note.trim(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#0F172A] border border-slate-800 rounded-2xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-mono-num font-black text-amber-400 text-lg">
              #{square.id < 10 ? `0${square.id}` : square.id}
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Square #{square.id}
              </h3>
              <p className="text-xs text-slate-400">
                Row {square.row + 1} · Col {square.col + 1}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Coordinate details */}
        <div className="px-6 py-3 bg-slate-950/60 border-b border-slate-800/80 grid grid-cols-2 gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: settings.homeTeam.primaryColor }}
            />
            <span className="text-slate-400 truncate">{settings.homeTeam.short}:</span>
            <span className="font-mono-num font-bold text-amber-400">
              Digit {rowDigit}
            </span>
          </div>
          <div className="flex items-center gap-2 justify-end">
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: settings.awayTeam.primaryColor }}
            />
            <span className="text-slate-400 truncate">{settings.awayTeam.short}:</span>
            <span className="font-mono-num font-bold text-amber-400">
              Digit {colDigit}
            </span>
          </div>
        </div>

        {/* Winner Announcement if applicable */}
        {squareWins.length > 0 && (
          <div className="mx-6 mt-4 p-3 bg-gradient-to-r from-amber-950/80 to-amber-900/40 border border-amber-500/50 rounded-xl flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center shrink-0">
              <Trophy className="w-5 h-5 fill-slate-950" />
            </div>
            <div className="text-xs">
              <div className="font-extrabold text-amber-300">
                Quarter Winner!
              </div>
              <div className="text-amber-100/90 font-medium">
                {squareWins.map((w) => `${w.label} ($${w.payoutAmount})`).join(', ')}
              </div>
            </div>
          </div>
        )}

        {/* Content Body based on status */}
        <div className="p-6">
          {square.status === 'available' ? (
            /* CLAIM FORM */
            <form onSubmit={handleSubmitClaim} className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs">
                <span className="text-slate-400">Cost to Claim:</span>
                <span className="font-mono-num font-extrabold text-emerald-400 text-base">
                  ${settings.squarePrice}.00
                </span>
              </div>

              {validationError && (
                <div className="p-2.5 bg-red-950/60 border border-red-800 text-red-200 text-xs rounded-lg">
                  {validationError}
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-amber-400" />
                  <span>Your Full Name or Nickname *</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Alex Miller"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (validationError) setValidationError('');
                  }}
                  className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>Email or Phone (For Winner Payouts)</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g., alex@example.com or 555-0192"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Optional Note / Team Trash Talk
                </label>
                <input
                  type="text"
                  placeholder="e.g., Chiefs Kingdom all day!"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm rounded-xl transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Select & Pay via Venmo / Cash App</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[11px] text-slate-500 text-center mt-2">
                  Next step gives you instant Venmo & Cash App QR codes and pre-filled memos.
                </p>
              </div>
            </form>
          ) : (
            /* CLAIMED OR PENDING DETAILS */
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Claimed By:</span>
                  <span className="font-bold text-white text-sm">
                    {square.ownerName || 'Anonymous'}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Status:</span>
                  {square.status === 'confirmed' ? (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Paid & Confirmed
                    </span>
                  ) : (
                    <span className="text-amber-400 font-semibold flex items-center gap-1">
                      <RotateCcw className="w-3.5 h-3.5 animate-spin" /> Pending Approval
                    </span>
                  )}
                </div>

                {square.paymentMethod && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Payment Channel:</span>
                    <span className="font-semibold capitalize text-slate-200">
                      {square.paymentMethod === 'venmo' ? 'Venmo' : 'Cash App'}
                    </span>
                  </div>
                )}

                {square.ownerContact && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Contact:</span>
                    <span className="text-slate-300 font-mono-num">
                      {square.ownerContact}
                    </span>
                  </div>
                )}

                {square.paymentNote && (
                  <div className="pt-2 border-t border-slate-800">
                    <span className="text-slate-500 block mb-1">Memo / Ref:</span>
                    <span className="text-slate-300 italic font-mono-num bg-slate-900 px-2 py-1 rounded block">
                      {square.paymentNote}
                    </span>
                  </div>
                )}
              </div>

              {/* Commissioner management buttons */}
              {isCommissioner && (
                <div className="pt-2 space-y-2">
                  <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1">
                    <Shield className="w-3 h-3" /> Commissioner Actions
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {square.status === 'pending_verification' && onApproveSquare && (
                      <button
                        onClick={() => {
                          onApproveSquare(square.id);
                          onClose();
                        }}
                        className="py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Confirm Payment</span>
                      </button>
                    )}

                    {onReleaseSquare && (
                      <button
                        onClick={() => {
                          if (confirm(`Release Square #${square.id} back to available?`)) {
                            onReleaseSquare(square.id);
                            onClose();
                          }
                        }}
                        className={`py-2 px-3 bg-red-950/80 hover:bg-red-900 border border-red-800 text-red-200 font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                          square.status === 'pending_verification' ? '' : 'col-span-2'
                        }`}
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Release to Available</span>
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
