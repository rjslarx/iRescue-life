import React, { useState } from 'react';
import { X, Copy, Check, Share2, MessageCircle } from 'lucide-react';
import { copyToClipboard } from '../utils/paymentLinks';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  poolName: string;
  squarePrice: number;
  availableCount: number;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  poolName,
  squarePrice,
  availableCount,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedText, setCopiedText] = useState(false);

  if (!isOpen) return null;

  const appUrl = typeof window !== 'undefined' ? window.location.href : 'https://football-squares.app';
  const shareText = `🏈 Join our Football Squares Pool: "${poolName}"!\n\n💰 Squares are $${squarePrice} each (${availableCount} left).\n📱 Pick your square and pay instantly with Venmo or Cash App.\n🏆 Winners paid out after every quarter!\n\n👉 Join here: ${appUrl}`;

  const handleCopyLink = async () => {
    const ok = await copyToClipboard(appUrl);
    if (ok) {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleCopyText = async () => {
    const ok = await copyToClipboard(shareText);
    if (ok) {
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-md bg-[#0F172A] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Invite Friends & Players
              </h3>
              <p className="text-xs text-slate-400">
                Share pool link via SMS, group chat or social media
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-xs">
          {/* Quick link copy */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1.5">
              Pool URL Link:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={appUrl}
                className="grow px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-white font-mono-num text-xs truncate focus:outline-none"
              />
              <button
                onClick={handleCopyLink}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-colors cursor-pointer shrink-0 flex items-center gap-1.5"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Group Chat Text message copy */}
          <div>
            <label className="block font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>Ready-to-Paste Group Chat Invite:</span>
            </label>
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-300 font-mono-num whitespace-pre-line text-[11px] leading-relaxed max-h-40 overflow-y-auto">
              {shareText}
            </div>
            <button
              onClick={handleCopyText}
              className="mt-2.5 w-full py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md shadow-amber-500/20"
            >
              {copiedText ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Invite Copied to Clipboard!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Full Message to Clipboard</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
