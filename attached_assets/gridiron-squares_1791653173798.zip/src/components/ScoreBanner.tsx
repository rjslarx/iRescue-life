import React from 'react';
import { PoolSettings, GameScores } from '../types/pool';
import { Trophy, DollarSign, Clock, Users } from 'lucide-react';

interface ScoreBannerProps {
  settings: PoolSettings;
  scores: GameScores;
  confirmedCount: number;
  pendingCount: number;
  availableCount: number;
  totalPot: number;
  onOpenScoreboard: () => void;
  onQuickClaim: () => void;
}

export const ScoreBanner: React.FC<ScoreBannerProps> = ({
  settings,
  scores,
  confirmedCount,
  pendingCount,
  availableCount,
  totalPot,
  onOpenScoreboard,
  onQuickClaim,
}) => {
  const currentQText = {
    pregame: 'Pregame',
    q1: '1st Quarter',
    q2: '2nd Quarter',
    halftime: 'Halftime',
    q3: '3rd Quarter',
    q4: '4th Quarter',
    final: 'Final',
  }[scores.currentQuarter];

  // Active home & away total score
  const getLatestScore = () => {
    if (scores.q4.isComplete && scores.q4.home !== null && scores.q4.away !== null) {
      return { home: scores.q4.home, away: scores.q4.away };
    }
    if (scores.q3.isComplete && scores.q3.home !== null && scores.q3.away !== null) {
      return { home: scores.q3.home, away: scores.q3.away };
    }
    if (scores.q2.isComplete && scores.q2.home !== null && scores.q2.away !== null) {
      return { home: scores.q2.home, away: scores.q2.away };
    }
    if (scores.q1.isComplete && scores.q1.home !== null && scores.q1.away !== null) {
      return { home: scores.q1.home, away: scores.q1.away };
    }
    return {
      home: scores.q3.home ?? scores.q2.home ?? scores.q1.home ?? 0,
      away: scores.q3.away ?? scores.q2.away ?? scores.q1.away ?? 0,
    };
  };

  const currentScore = getLatestScore();

  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-900 to-[#0B131E] border-b border-slate-800">
      {/* Background stadium subtle glow */}
      <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-500 via-slate-900 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          
          {/* Matchup & Score Card */}
          <div className="lg:col-span-7 bg-slate-950/80 border border-slate-800 rounded-xl p-4 sm:p-5 shadow-xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-semibold text-slate-300">{currentQText}</span>
                <span aria-hidden="true">·</span>
                <span>{settings.eventDate}</span>
              </div>
              <button
                onClick={onOpenScoreboard}
                className="text-amber-400 hover:text-amber-300 font-medium text-xs flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>Quarter Log & Payouts</span>
                <span aria-hidden="true">→</span>
              </button>
            </div>

            {/* Scoreboard display */}
            <div className="grid grid-cols-11 items-center gap-2">
              {/* Home Team */}
              <div className="col-span-4 flex items-center gap-3">
                <div
                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center font-black text-white text-base sm:text-lg shadow-md shrink-0"
                  style={{ backgroundColor: settings.homeTeam.primaryColor }}
                >
                  {settings.homeTeam.short}
                </div>
                <div className="min-w-0">
                  <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Home</div>
                  <div className="text-base sm:text-lg font-bold text-white truncate">
                    {settings.homeTeam.name}
                  </div>
                </div>
              </div>

              {/* Big Score Numbers */}
              <div className="col-span-3 text-center flex items-center justify-center gap-3">
                <span className="text-3xl sm:text-4xl font-extrabold text-white font-mono-num">
                  {currentScore.home}
                </span>
                <span className="text-sm font-bold text-slate-500">-</span>
                <span className="text-3xl sm:text-4xl font-extrabold text-white font-mono-num">
                  {currentScore.away}
                </span>
              </div>

              {/* Away Team */}
              <div className="col-span-4 flex items-center justify-end gap-3 text-right">
                <div className="min-w-0">
                  <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Away</div>
                  <div className="text-base sm:text-lg font-bold text-white truncate">
                    {settings.awayTeam.name}
                  </div>
                </div>
                <div
                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg flex items-center justify-center font-black text-white text-base sm:text-lg shadow-md shrink-0"
                  style={{ backgroundColor: settings.awayTeam.primaryColor }}
                >
                  {settings.awayTeam.short}
                </div>
              </div>
            </div>

            {/* Current Winning Digits note */}
            {settings.numbersLocked && (
              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="text-slate-300 font-medium">Active Winning Digits:</span>
                  <span className="font-mono-num text-amber-400 font-bold bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/40">
                    {settings.homeTeam.short} {currentScore.home % 10}
                  </span>
                  <span>—</span>
                  <span className="font-mono-num text-amber-400 font-bold bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/40">
                    {settings.awayTeam.short} {currentScore.away % 10}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500">Based on score last digits</span>
              </div>
            )}
          </div>

          {/* Quick Metrics & CTA */}
          <div className="lg:col-span-5 grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Metric 1: Total Pot */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                <span>Total Pot</span>
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono-num">
                ${totalPot.toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                ${settings.squarePrice} per square
              </div>
            </div>

            {/* Metric 2: Claimed Squares */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400 text-xs mb-1">
                <span>Squares Sold</span>
                <Users className="w-3.5 h-3.5 text-blue-400" />
              </div>
              <div className="text-2xl font-black text-white font-mono-num">
                {confirmedCount + pendingCount}<span className="text-sm text-slate-400 font-normal">/100</span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                {availableCount} available
              </div>
            </div>

            {/* Metric 3: Quarter Winner Pot & Action */}
            <div className="col-span-2 sm:col-span-1 bg-gradient-to-br from-amber-950/30 to-slate-950/80 border border-amber-900/30 rounded-xl p-3.5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-amber-300 text-xs mb-1">
                <span>Halftime / Final</span>
                <Trophy className="w-3.5 h-3.5 text-amber-400" />
              </div>
              <div className="text-xl font-black text-amber-400 font-mono-num">
                ${((totalPot * settings.payoutPercentages.q4) / 100).toFixed(0)}
              </div>
              <button
                onClick={onQuickClaim}
                className="mt-2 w-full py-1.5 px-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer text-center whitespace-nowrap shadow-sm"
              >
                Claim a Square
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
