import React, { useState } from 'react';
import { Square, PoolSettings, QuarterWinner, GridFilter } from '../types/pool';
import { Trophy, Clock, CheckCircle2, Search, Filter } from 'lucide-react';

interface FootballGridProps {
  squares: Square[];
  settings: PoolSettings;
  winners: QuarterWinner[];
  filter: GridFilter;
  onFilterChange: (filter: GridFilter) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  currentUser: string;
  onSelectSquare: (square: Square) => void;
}

export const FootballGrid: React.FC<FootballGridProps> = ({
  squares,
  settings,
  winners,
  filter,
  onFilterChange,
  searchQuery,
  onSearchChange,
  currentUser,
  onSelectSquare,
}) => {
  const [hoveredCell, setHoveredCell] = useState<{ row: number; col: number } | null>(null);

  // Map winning squares by id for quick lookup
  const winnerMap = new Map<number, QuarterWinner[]>();
  winners.forEach(w => {
    const list = winnerMap.get(w.squareId) || [];
    list.push(w);
    winnerMap.set(w.squareId, list);
  });

  // Helper to check if a square matches the current filter
  const matchesFilter = (square: Square) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchesName = square.ownerName?.toLowerCase().includes(q);
      const matchesId = square.id.toString() === q || `square #${square.id}`.includes(q);
      if (!matchesName && !matchesId) return false;
    }

    if (filter === 'all') return true;
    if (filter === 'available') return square.status === 'available';
    if (filter === 'pending') return square.status === 'pending_verification';
    if (filter === 'winners') return winnerMap.has(square.id);
    if (filter === 'mine') {
      if (!currentUser) return false;
      return (
        square.ownerName?.toLowerCase().includes(currentUser.toLowerCase()) ||
        square.ownerContact?.toLowerCase().includes(currentUser.toLowerCase())
      );
    }
    return true;
  };

  return (
    <div id="board" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Grid Controls: Filter tabs & Search */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-extrabold text-white tracking-tight flex items-center gap-2">
            <span>The 100 Squares Board</span>
            {!settings.numbersLocked ? (
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-800/40">
                Numbers Hidden (Locked at Kickoff)
              </span>
            ) : (
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/40 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Digits Active (0-9)
              </span>
            )}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Tap an open cell to claim with Venmo or Cash App. Coordinates reveal final digit match.
          </p>
        </div>

        {/* Filter controls & Search */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Search box */}
          <div className="relative min-w-[180px] grow md:grow-0">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search player or #..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                ×
              </button>
            )}
          </div>

          {/* Segmented filter buttons */}
          <div className="flex items-center p-1 bg-slate-900 rounded-lg border border-slate-800 text-xs font-medium">
            <button
              onClick={() => onFilterChange('all')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer whitespace-nowrap ${
                filter === 'all'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All (100)
            </button>
            <button
              onClick={() => onFilterChange('available')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer whitespace-nowrap ${
                filter === 'available'
                  ? 'bg-emerald-900/60 text-emerald-200 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Available
            </button>
            <button
              onClick={() => onFilterChange('pending')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer whitespace-nowrap ${
                filter === 'pending'
                  ? 'bg-amber-900/60 text-amber-200 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Pending
            </button>
            <button
              onClick={() => onFilterChange('winners')}
              className={`px-3 py-1 rounded-md transition-all cursor-pointer whitespace-nowrap ${
                filter === 'winners'
                  ? 'bg-amber-500 text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Winners
            </button>
            {currentUser && (
              <button
                onClick={() => onFilterChange('mine')}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer whitespace-nowrap ${
                  filter === 'mine'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                My Squares
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Grid Container with horizontal scroll for responsiveness */}
      <div className="bg-[#0B121E] border border-slate-800 rounded-2xl p-3 sm:p-5 shadow-2xl overflow-x-auto">
        <div className="min-w-[780px]">
          
          {/* Top Header: Away Team Badge & Title */}
          <div className="ml-24 sm:ml-28 mb-2 flex items-center justify-center gap-2">
            <span
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: settings.awayTeam.primaryColor }}
            />
            <span className="text-xs font-bold text-slate-300 uppercase tracking-widest">
              Away Team: {settings.awayTeam.name} ({settings.awayTeam.short})
            </span>
            <span className="text-[11px] text-slate-500 font-mono-num">(Column Digits)</span>
          </div>

          {/* Grid Table */}
          <table className="w-full border-collapse select-none">
            <thead>
              <tr>
                {/* Top-left corner */}
                <th className="w-24 sm:w-28 h-12 p-1 text-center align-middle bg-slate-950/60 border border-slate-800 rounded-tl-lg">
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                    Home \ Away
                  </div>
                </th>

                {/* Away Team Column Header Numbers (0 to 9) */}
                {Array.from({ length: 10 }).map((_, col) => {
                  const digit = settings.numbersLocked ? settings.colNumbers[col] : '?';
                  const isColHovered = hoveredCell?.col === col;

                  return (
                    <th
                      key={`col-head-${col}`}
                      className={`w-[72px] h-12 p-1 text-center align-middle border border-slate-800 font-mono-num text-base font-black transition-colors ${
                        isColHovered
                          ? 'bg-amber-500 text-slate-950 shadow-md scale-105 z-10'
                          : 'bg-slate-950/80 text-amber-400'
                      }`}
                    >
                      <div className="flex flex-col items-center justify-center">
                        <span className="text-[10px] text-slate-500 font-sans font-normal">
                          Col {col + 1}
                        </span>
                        <span>{digit}</span>
                      </div>
                    </th>
                  );
                })}
              </tr>
            </thead>

            <tbody>
              {Array.from({ length: 10 }).map((_, row) => {
                const rowDigit = settings.numbersLocked ? settings.rowNumbers[row] : '?';
                const isRowHovered = hoveredCell?.row === row;

                return (
                  <tr key={`row-${row}`}>
                    {/* Home Team Row Header Number */}
                    <th
                      className={`w-24 sm:w-28 h-16 p-2 text-center align-middle border border-slate-800 transition-colors ${
                        isRowHovered
                          ? 'bg-amber-500 text-slate-950 shadow-md z-10'
                          : 'bg-slate-950/80 text-white'
                      }`}
                    >
                      <div className="flex items-center justify-between px-1">
                        <div className="text-left">
                          <span className="text-[10px] text-slate-500 font-sans block">
                            Row {row + 1}
                          </span>
                          <span className="text-xs font-bold font-sans text-slate-300">
                            {settings.homeTeam.short}
                          </span>
                        </div>
                        <span className="text-base font-mono-num font-black text-amber-400">
                          {rowDigit}
                        </span>
                      </div>
                    </th>

                    {/* 10 Square Cells in this row */}
                    {Array.from({ length: 10 }).map((_, col) => {
                      const squareId = row * 10 + col;
                      const square = squares.find((s) => s.id === squareId) || {
                        id: squareId,
                        row,
                        col,
                        status: 'available',
                      };

                      const isHovered = hoveredCell?.row === row && hoveredCell?.col === col;
                      const isHighlighted = matchesFilter(square);
                      const winningQuarters = winnerMap.get(square.id);
                      const isWinner = winningQuarters && winningQuarters.length > 0;
                      const colDigit = settings.numbersLocked ? settings.colNumbers[col] : '?';

                      // Cell background styling based on status
                      let cellBg = 'bg-slate-950/40 hover:bg-slate-800/80 text-slate-300';
                      let borderStyle = 'border-slate-800/90';

                      if (isWinner) {
                        cellBg = 'bg-gradient-to-br from-amber-950/80 to-amber-900/60 text-amber-100 ring-2 ring-amber-400 shadow-lg shadow-amber-500/20';
                        borderStyle = 'border-amber-400';
                      } else if (square.status === 'confirmed') {
                        cellBg = 'bg-slate-900/90 hover:bg-slate-850 text-white';
                      } else if (square.status === 'pending_verification') {
                        cellBg = 'bg-blue-950/40 hover:bg-blue-900/40 text-blue-200 border-dashed';
                        borderStyle = 'border-blue-500/60';
                      } else if (square.status === 'reserved') {
                        cellBg = 'bg-amber-950/30 hover:bg-amber-900/30 text-amber-200';
                        borderStyle = 'border-amber-600/50';
                      }

                      // Mute unhighlighted cells when searching/filtering
                      const opacityStyle = isHighlighted ? 'opacity-100' : 'opacity-25 hover:opacity-100';

                      return (
                        <td
                          key={`cell-${squareId}`}
                          onMouseEnter={() => setHoveredCell({ row, col })}
                          onMouseLeave={() => setHoveredCell(null)}
                          onClick={() => onSelectSquare(square)}
                          className={`w-[72px] h-16 p-1 border ${borderStyle} ${cellBg} ${opacityStyle} transition-all duration-150 cursor-pointer relative align-top`}
                          title={`Square #${square.id} · ${square.status}`}
                        >
                          {/* Inner cell layout */}
                          <div className="h-full flex flex-col justify-between p-0.5">
                            {/* Top row: Square ID and Status icon */}
                            <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono-num leading-none">
                              <span className="font-semibold text-slate-400">
                                #{square.id < 10 ? `0${square.id}` : square.id}
                              </span>
                              
                              {/* Winner Trophy badge */}
                              {isWinner ? (
                                <span className="flex items-center gap-0.5 text-amber-400 font-bold bg-amber-950/90 px-1 rounded text-[9px] border border-amber-600/60">
                                  <Trophy className="w-2.5 h-2.5 fill-amber-400" />
                                  <span>{winningQuarters[0].label}</span>
                                </span>
                              ) : square.status === 'pending_verification' ? (
                                <span className="text-blue-400 font-medium" title="Pending confirmation">
                                  <Clock className="w-2.5 h-2.5 animate-pulse" />
                                </span>
                              ) : square.status === 'available' ? (
                                <span className="text-emerald-500 text-[10px] font-bold">
                                  ${settings.squarePrice}
                                </span>
                              ) : null}
                            </div>

                            {/* Center: Owner Name or Available Prompt */}
                            <div className="my-auto text-center px-0.5">
                              {square.status === 'available' ? (
                                <div className="text-[11px] font-medium text-emerald-400/90 group-hover:text-emerald-300">
                                  Open
                                </div>
                              ) : square.status === 'pending_verification' ? (
                                <div className="text-[10px] font-medium text-blue-300 truncate">
                                  {square.ownerName || 'Pending'}
                                </div>
                              ) : (
                                <div className="text-[11px] font-bold text-slate-100 truncate">
                                  {square.ownerName}
                                </div>
                              )}
                            </div>

                            {/* Bottom: Payment Method tag if confirmed */}
                            <div className="flex items-center justify-between text-[9px] leading-none">
                              {square.paymentMethod === 'venmo' ? (
                                <span className="text-[#008CFF] font-semibold text-[9px]">
                                  Venmo
                                </span>
                              ) : square.paymentMethod === 'cashapp' ? (
                                <span className="text-[#00D632] font-semibold text-[9px]">
                                  CashApp
                                </span>
                              ) : (
                                <span />
                              )}

                              {isHovered && (
                                <span className="text-amber-400 font-mono-num font-bold text-[9px]">
                                  {rowDigit}-{colDigit}
                                </span>
                              )}
                            </div>
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Left Footer: Home Team Indicator */}
          <div className="mt-3 flex items-center justify-start gap-2 text-xs text-slate-400">
            <span
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: settings.homeTeam.primaryColor }}
            />
            <span className="font-bold text-slate-300 uppercase tracking-widest">
              Home Team: {settings.homeTeam.name} ({settings.homeTeam.short})
            </span>
            <span className="text-[11px] text-slate-500 font-mono-num">(Row Digits)</span>
          </div>

        </div>
      </div>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
        <div className="flex flex-wrap items-center gap-5">
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded bg-slate-950 border border-slate-800" />
            <span>Available (${settings.squarePrice})</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded bg-blue-950/60 border border-dashed border-blue-500" />
            <span>Pending Commissioner Approval</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded bg-slate-900 border border-slate-700" />
            <span>Paid & Confirmed</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3.5 h-3.5 rounded bg-amber-500/30 border border-amber-400" />
            <span>Quarter Winner</span>
          </div>
        </div>

        <div className="text-[11px] text-slate-500">
          Tip: Click any square to view details or claim with Venmo / Cash App
        </div>
      </div>
    </div>
  );
};
