import React, { useState, useEffect } from 'react';
import { Square, PoolSettings, PaymentMethod } from '../types/pool';
import {
  X,
  Copy,
  Check,
  ExternalLink,
  Smartphone,
  ShieldCheck,
  QrCode,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import {
  getVenmoDeepLink,
  getVenmoWebLink,
  getCashAppDeepLink,
  generateQrCode,
  copyToClipboard,
  cleanHandle,
} from '../utils/paymentLinks';
import { playPaymentSubmittedSound } from '../utils/soundEffects';

interface PaymentModalProps {
  square: Square | null;
  settings: PoolSettings;
  isOpen: boolean;
  claimantData: { name: string; contact: string; note: string };
  onClose: () => void;
  onSubmitPayment: (
    squareId: number,
    method: PaymentMethod,
    claimant: { name: string; contact: string; note: string; transactionRef: string }
  ) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  square,
  settings,
  isOpen,
  claimantData,
  onClose,
  onSubmitPayment,
}) => {
  const [method, setMethod] = useState<'venmo' | 'cashapp'>('venmo');
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [transactionRef, setTransactionRef] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const amount = settings.squarePrice;
  const paymentMemo = `Square #${square?.id ?? 0} - ${claimantData.name}`;

  // Generate QR code whenever method or square changes
  useEffect(() => {
    if (!isOpen || !square) return;

    let targetUrl = '';
    if (method === 'venmo') {
      targetUrl = getVenmoWebLink({
        handle: settings.venmoHandle,
        amount,
        note: paymentMemo,
      });
    } else {
      targetUrl = getCashAppDeepLink({
        handle: settings.cashAppHandle,
        amount,
        note: paymentMemo,
      });
    }

    generateQrCode(targetUrl, method === 'cashapp').then((url) => {
      setQrCodeUrl(url);
    });
  }, [isOpen, square, method, settings, amount, paymentMemo]);

  if (!isOpen || !square) return null;

  const handleCopy = async (text: string, fieldName: string) => {
    const ok = await copyToClipboard(text);
    if (ok) {
      setCopiedField(fieldName);
      setTimeout(() => setCopiedField(null), 2000);
    }
  };

  const handleConfirmSent = () => {
    setIsSubmitting(true);
    playPaymentSubmittedSound();
    setTimeout(() => {
      onSubmitPayment(square.id, method, {
        ...claimantData,
        transactionRef: transactionRef.trim(),
      });
      setIsSubmitting(false);
      onClose();
    }, 400);
  };

  const venmoDeep = getVenmoDeepLink({
    handle: settings.venmoHandle,
    amount,
    note: paymentMemo,
  });
  const venmoWeb = getVenmoWebLink({
    handle: settings.venmoHandle,
    amount,
    note: paymentMemo,
  });
  const cashAppUrl = getCashAppDeepLink({
    handle: settings.cashAppHandle,
    amount,
    note: paymentMemo,
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg bg-[#0F172A] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold font-mono-num">
              <DollarSign className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Complete Square Checkout
              </h3>
              <p className="text-xs text-slate-400">
                Square #{square.id} · <span className="text-emerald-400 font-bold">${amount}.00</span> Due
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Container */}
        <div className="p-6 overflow-y-auto space-y-5 grow">
          
          {/* Reservation Summary */}
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 flex items-center justify-between text-xs">
            <div>
              <div className="text-slate-400">Claimant:</div>
              <div className="font-bold text-white text-sm">{claimantData.name}</div>
              {claimantData.contact && (
                <div className="text-[11px] text-slate-500">{claimantData.contact}</div>
              )}
            </div>
            <div className="text-right">
              <div className="text-slate-400">Amount Due:</div>
              <div className="text-lg font-black text-emerald-400 font-mono-num">
                ${amount}.00
              </div>
            </div>
          </div>

          {/* Payment Method Selector Tabs */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Choose Your Payment App:
            </label>
            <div className="grid grid-cols-2 gap-3">
              {/* Venmo Tab */}
              <button
                type="button"
                onClick={() => setMethod('venmo')}
                className={`p-3 rounded-xl border flex items-center justify-center gap-2.5 transition-all cursor-pointer font-bold text-sm ${
                  method === 'venmo'
                    ? 'bg-[#008CFF]/15 border-[#008CFF] text-[#008CFF] shadow-lg shadow-[#008CFF]/10 ring-1 ring-[#008CFF]'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="w-6 h-6 rounded-md bg-[#008CFF] text-white flex items-center justify-center text-xs font-black">
                  V
                </div>
                <span>Venmo</span>
              </button>

              {/* Cash App Tab */}
              <button
                type="button"
                onClick={() => setMethod('cashapp')}
                className={`p-3 rounded-xl border flex items-center justify-center gap-2.5 transition-all cursor-pointer font-bold text-sm ${
                  method === 'cashapp'
                    ? 'bg-[#00D632]/15 border-[#00D632] text-[#00D632] shadow-lg shadow-[#00D632]/10 ring-1 ring-[#00D632]'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="w-6 h-6 rounded-md bg-[#00D632] text-slate-950 flex items-center justify-center text-xs font-black">
                  $
                </div>
                <span>Cash App</span>
              </button>
            </div>
          </div>

          {/* Method Content */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
            
            {/* Top row: Scan QR or Click App button */}
            <div className="flex flex-col sm:flex-row items-center gap-5">
              {/* QR Code Container */}
              <div className="shrink-0 flex flex-col items-center">
                <div className="w-36 h-36 bg-slate-900 rounded-xl p-2 border border-slate-700 flex items-center justify-center shadow-md relative group">
                  {qrCodeUrl ? (
                    <img
                      src={qrCodeUrl}
                      alt={`${method} QR Code`}
                      className="w-full h-full object-contain rounded-lg"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="flex flex-col items-center text-slate-500 text-xs">
                      <QrCode className="w-8 h-8 mb-1" />
                      <span>Generating QR...</span>
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                  <Smartphone className="w-3 h-3" /> Scan with camera
                </span>
              </div>

              {/* Quick Details & Launch Button */}
              <div className="space-y-3 grow w-full">
                {/* Copy Commissioner Handle */}
                <div>
                  <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                    <span>Send ${amount}.00 to:</span>
                    {copiedField === 'handle' && (
                      <span className="text-emerald-400 font-medium text-[10px] flex items-center gap-0.5">
                        <Check className="w-3 h-3" /> Copied!
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="grow bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono-num font-bold text-white flex items-center justify-between">
                      <span>
                        {method === 'venmo'
                          ? `@${cleanHandle(settings.venmoHandle)}`
                          : `$${cleanHandle(settings.cashAppHandle)}`}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        handleCopy(
                          method === 'venmo'
                            ? cleanHandle(settings.venmoHandle)
                            : cleanHandle(settings.cashAppHandle),
                          'handle'
                        )
                      }
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer shrink-0"
                      title="Copy handle"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Copy Required Note */}
                <div>
                  <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1 font-semibold text-amber-400">
                      <AlertCircle className="w-3 h-3" /> Required Memo Note:
                    </span>
                    {copiedField === 'memo' && (
                      <span className="text-emerald-400 font-medium text-[10px] flex items-center gap-0.5">
                        <Check className="w-3 h-3" /> Copied!
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="grow bg-slate-900 border border-amber-500/30 rounded-lg px-3 py-1.5 text-xs font-mono-num font-bold text-amber-200 truncate">
                      {paymentMemo}
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(paymentMemo, 'memo')}
                      className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer shrink-0"
                      title="Copy memo"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* App Deep link button */}
                {method === 'venmo' ? (
                  <div className="space-y-1.5 pt-1">
                    <a
                      href={venmoDeep}
                      className="w-full py-2 px-3 bg-[#008CFF] hover:bg-[#007AE0] text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-md shadow-[#008CFF]/20"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Open Venmo App</span>
                    </a>
                    <a
                      href={venmoWeb}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full text-center text-[11px] text-slate-400 hover:text-white block py-0.5 transition-colors"
                    >
                      or open Venmo on web
                    </a>
                  </div>
                ) : (
                  <div className="space-y-1.5 pt-1">
                    <a
                      href={cashAppUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 px-3 bg-[#00D632] hover:bg-[#00BD2C] text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-md shadow-[#00D632]/20"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Pay ${amount} on Cash App</span>
                    </a>
                  </div>
                )}
              </div>
            </div>

            {/* Instruction banner */}
            <div className="pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                Please include <strong className="text-white">"{paymentMemo}"</strong> in your payment note so Commissioner {cleanHandle(settings.venmoHandle)} can immediately verify and confirm your square.
              </span>
            </div>
          </div>

          {/* Step 2: Confirm you sent the payment */}
          <div className="space-y-3 pt-1">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Optional: Venmo / Cash App Username or Last 4 Digits
              </label>
              <input
                type="text"
                placeholder="e.g., Sent from @Alex-Miller-99"
                value={transactionRef}
                onChange={(e) => setTransactionRef(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-950 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition-colors"
              />
            </div>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={handleConfirmSent}
              className="w-full py-3 px-4 bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-slate-950 font-extrabold text-sm rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>Submitting Reservation...</span>
              ) : (
                <>
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>I've Sent the Payment (${amount}.00)</span>
                </>
              )}
            </button>

            <p className="text-[11px] text-slate-400 text-center">
              Your square will be marked as <strong>Pending Verification</strong> and secured while the commissioner checks the payment ledger.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};
