import React from 'react';
import { Shield, ShieldAlert, Share2, HelpCircle, Trophy } from 'lucide-react';

interface NavbarProps {
  poolName: string;
  isCommissioner: boolean;
  onToggleCommissioner: () => void;
  onOpenRules: () => void;
  onOpenShare: () => void;
  onOpenWinners: () => void;
  pendingCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  poolName,
  isCommissioner,
  onToggleCommissioner,
  onOpenRules,
  onOpenShare,
  onOpenWinners,
  pendingCount,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#090D16]/95 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-md">
            <svg
              className="w-5 h-5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <ellipse cx="12" cy="12" rx="10" ry="6" transform="rotate(-45 12 12)" />
              <line x1="8" y1="8" x2="16" y2="16" />
              <line x1="10" y1="12" x2="14" y2="12" />
              <line x1="12" y1="10" x2="12" y2="14" />
            </svg>
          </div>
          <div>
            <span className="text-base font-extrabold tracking-tight text-white whitespace-nowrap block">
              GRIDIRON SQUARES
            </span>
            <span className="text-xs text-slate-400 truncate max-w-[200px] sm:max-w-xs block">
              {poolName}
            </span>
          </div>
        </div>

        {/* Zone 2: Nav Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          <a
            href="#board"
            className="hover:text-white transition-colors whitespace-nowrap shrink-0"
          >
            The Board
          </a>
          <button
            onClick={onOpenWinners}
            className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          >
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>Quarter Payouts</span>
          </button>
          <button
            onClick={onOpenRules}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-slate-400" />
            <span>How to Play</span>
          </button>
          <button
            onClick={onOpenShare}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
          >
            <Share2 className="w-4 h-4 text-slate-400" />
            <span>Invite Friends</span>
          </button>
        </nav>

        {/* Zone 3: Primary Action (Commissioner Mode toggle) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenRules}
            className="md:hidden p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            title="How to play"
            aria-label="How to play"
          >
            <HelpCircle className="w-5 h-5" />
          </button>
          <button
            onClick={onOpenShare}
            className="md:hidden p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            title="Share pool"
            aria-label="Share pool"
          >
            <Share2 className="w-5 h-5" />
          </button>

          <button
            onClick={onToggleCommissioner}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
              isCommissioner
                ? 'bg-amber-500 text-slate-950 hover:bg-amber-400 shadow-md shadow-amber-500/20'
                : 'bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700'
            }`}
          >
            {isCommissioner ? (
              <>
                <ShieldAlert className="w-4 h-4 text-slate-950" />
                <span>Commissioner View</span>
                {pendingCount > 0 && (
                  <span className="w-5 h-5 bg-red-600 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
                    {pendingCount}
                  </span>
                )}
              </>
            ) : (
              <>
                <Shield className="w-4 h-4 text-slate-400" />
                <span>Commissioner Mode</span>
                {pendingCount > 0 && (
                  <span className="w-4 h-4 bg-amber-500 text-slate-950 rounded-full text-[10px] font-bold flex items-center justify-center">
                    {pendingCount}
                  </span>
                )}
              </>
            )}
          </button>
        </div>

      </div>
    </header>
  );
};
