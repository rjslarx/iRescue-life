import React from 'react';
import { PoolSettings, GameScores, QuarterWinner } from '../types/pool';
import { Trophy, CheckCircle, Clock, X, DollarSign } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ScoreboardPayoutsProps {
  settings: PoolSettings;
  scores: GameScores;
  winners: QuarterWinner[];
  isOpen: boolean;
  onClose: () => void;
  onSelectWinnerSquare: (squareId: number) => void;
}

export const ScoreboardPayouts: React.FC<ScoreboardPayoutsProps> = ({
  settings,
  scores,
  winners,
  isOpen,
  onClose,
  onSelectWinnerSquare,
}) => {
  if (!isOpen) return null;

  const totalPot = settings.squarePrice * 100;

  const triggerCelebration = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#F59E0B', '#10B981', '#008CFF', '#FFFFFF'],
    });
  };

  const quarters = [
    { key: 'q1' as const, label: '1st Quarter', score: scores.q1, pct: settings.payoutPercentages.q1 },
    { key: 'q2' as const, label: 'Halftime (2nd Qtr)', score: scores.q2, pct: settings.payoutPercentages.q2 },
    { key: 'q3' as const, label: '3rd Quarter', score: scores.q3, pct: settings.payoutPercentages.q3 },
    { key: 'q4' as const, label: 'Final Score', score: scores.q4, pct: settings.payoutPercentages.q4 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-[#0F172A] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                Quarter Payouts & Winner Log
              </h3>
              <p className="text-xs text-slate-400">
                Total Pot: <strong className="text-emerald-400 font-mono-num">${totalPot.toLocaleString()}</strong> · Last digit of each team's score wins
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto space-y-4 grow">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quarters.map(({ key, label, score, pct }) => {
              const prize = (totalPot * pct) / 100;
              const winner = winners.find((w) => w.quarter === key);
              const hasScore = score.home !== null && score.away !== null;

              return (
                <div
                  key={key}
                  className={`bg-slate-950 border rounded-2xl p-4.5 flex flex-col justify-between transition-all ${
                    score.isComplete
                      ? 'border-amber-500/60 shadow-lg shadow-amber-500/10'
                      : 'border-slate-800/80'
                  }`}
                >
                  <div>
                    {/* Header line */}
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs mb-3">
                      <span className="font-extrabold text-white">{label}</span>
                      <span className="font-black text-amber-400 font-mono-num text-sm">
                        ${prize.toFixed(0)} <span className="text-[11px] font-normal text-slate-400">({pct}%)</span>
                      </span>
                    </div>

                    {/* Quarter Score */}
                    <div className="flex items-center justify-between py-2 px-3 bg-slate-900/80 rounded-xl text-xs mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400 font-semibold">{settings.homeTeam.short}:</span>
                        <span className="font-mono-num font-bold text-white text-base">
                          {score.home !== null ? score.home : '—'}
                        </span>
                      </div>
                      <span className="text-slate-500 font-bold">vs</span>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400 font-semibold">{settings.awayTeam.short}:</span>
                        <span className="font-mono-num font-bold text-white text-base">
                          {score.away !== null ? score.away : '—'}
                        </span>
                      </div>
                    </div>

                    {/* Winner Detail */}
                    {hasScore && settings.numbersLocked ? (
                      <div className="p-3 bg-amber-950/30 border border-amber-600/30 rounded-xl text-xs space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] text-slate-400">
                          <span>Winning Coordinate Digits:</span>
                          <span className="font-mono-num font-bold text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/40">
                            {score.home! % 10} - {score.away! % 10}
                          </span>
                        </div>

                        {winner ? (
                          <div className="pt-1 flex items-center justify-between">
                            <div>
                              <div className="text-[10px] text-amber-300/80 uppercase font-semibold">
                                Quarter Winner:
                              </div>
                              <div className="font-extrabold text-white text-sm">
                                {winner.winnerName}
                              </div>
                            </div>
                            <button
                              onClick={() => {
                                onSelectWinnerSquare(winner.squareId);
                                onClose();
                              }}
                              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg cursor-pointer transition-colors shadow-sm"
                            >
                              Square #{winner.squareId}
                            </button>
                          </div>
                        ) : (
                          <div className="text-slate-500 italic text-[11px] pt-1">
                            Square unclaimed
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="p-3 bg-slate-900/40 border border-slate-800 rounded-xl text-xs text-slate-500 flex items-center gap-2">
                        <Clock className="w-4 h-4 text-slate-600" />
                        <span>Awaiting quarter final score</span>
                      </div>
                    )}
                  </div>

                  {/* Status footer */}
                  <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Status:</span>
                    {score.isComplete ? (
                      <span className="text-amber-400 font-bold flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" /> Official
                      </span>
                    ) : (
                      <span className="text-slate-500">In Progress</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick celebrate demo button */}
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span className="text-slate-300">
                Quarter winners receive immediate payout via their registered Venmo or Cash App contact.
              </span>
            </div>
            <button
              onClick={triggerCelebration}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold rounded-lg cursor-pointer transition-colors whitespace-nowrap shrink-0"
            >
              🎉 Confetti Blast
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
