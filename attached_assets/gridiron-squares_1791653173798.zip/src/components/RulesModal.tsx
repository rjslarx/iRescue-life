import React from 'react';
import { X, HelpCircle, Trophy, DollarSign, Smartphone } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  squarePrice: number;
}

export const RulesModal: React.FC<RulesModalProps> = ({
  isOpen,
  onClose,
  squarePrice,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="w-full max-w-xl bg-[#0F172A] border border-slate-800 rounded-3xl shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                How Football Squares Work
              </h3>
              <p className="text-xs text-slate-400">
                Official pool rules, winning coordinates & payout schedule
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs grow text-slate-300">
          
          {/* Step 1 */}
          <div className="flex gap-4 items-start">
            <div className="w-7 h-7 rounded-lg bg-amber-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0">
              1
            </div>
            <div>
              <h4 className="font-extrabold text-white text-sm mb-1">
                Pick Your Squares
              </h4>
              <p className="text-slate-400 leading-relaxed">
                Click any available square on the 10x10 board. Each square costs ${squarePrice}. You can pick as many squares as you want. At this stage, row and column numbers are hidden so all squares have equal odds.
              </p>
            </div>
          </div>

          {/* Step 2 */}
          <div className="flex gap-4 items-start">
            <div className="w-7 h-7 rounded-lg bg-[#008CFF] text-white font-black text-xs flex items-center justify-center shrink-0">
              2
            </div>
            <div>
              <h4 className="font-extrabold text-white text-sm mb-1 flex items-center gap-1.5">
                <span>Pay with Venmo or Cash App</span>
                <Smartphone className="w-4 h-4 text-emerald-400" />
              </h4>
              <p className="text-slate-400 leading-relaxed">
                Complete your payment in seconds using the generated QR code or pre-formatted deep link. Make sure to keep the pre-filled memo (e.g. <em>Square #24 - Your Name</em>). Once submitted, the commissioner verifies and confirms your square on the board.
              </p>
            </div>
          </div>

          {/* Step 3 */}
          <div className="flex gap-4 items-start">
            <div className="w-7 h-7 rounded-lg bg-emerald-500 text-slate-950 font-black text-xs flex items-center justify-center shrink-0">
              3
            </div>
            <div>
              <h4 className="font-extrabold text-white text-sm mb-1">
                Numbers Randomization at Kickoff
              </h4>
              <p className="text-slate-400 leading-relaxed">
                Once the grid is filled or right before kickoff, digits 0 through 9 are randomly shuffled and assigned to each team's row (Home) and column (Away).
              </p>
            </div>
          </div>

          {/* Step 4: The Winning Logic */}
          <div className="flex gap-4 items-start">
            <div className="w-7 h-7 rounded-lg bg-amber-400 text-slate-950 font-black text-xs flex items-center justify-center shrink-0">
              4
            </div>
            <div>
              <h4 className="font-extrabold text-white text-sm mb-1 flex items-center gap-1.5">
                <span>How Winners Are Determined</span>
                <Trophy className="w-4 h-4 text-amber-400" />
              </h4>
              <p className="text-slate-400 leading-relaxed mb-3">
                Winners are determined at the end of each quarter by taking the <strong>last digit</strong> of each team's score:
              </p>

              {/* Example callout box */}
              <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-2 font-mono-num text-xs">
                <div className="font-bold text-amber-400">
                  Example Scenario (End of 1st Quarter):
                </div>
                <div className="text-slate-300">
                  Kansas City: <strong className="text-white">14</strong> (Last Digit = <strong className="text-amber-400">4</strong>)
                </div>
                <div className="text-slate-300">
                  San Francisco: <strong className="text-white">7</strong> (Last Digit = <strong className="text-amber-400">7</strong>)
                </div>
                <div className="pt-1 border-t border-slate-800 text-emerald-400 font-bold">
                  Winning Square: Intersecting Row 4 and Column 7!
                </div>
              </div>
            </div>
          </div>

          {/* Prize Splits */}
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl">
            <div className="font-bold text-white mb-2 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <span>Standard Quarter Payout Distribution:</span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div className="p-2 bg-slate-900 rounded-lg">
                <div className="text-slate-400 text-[11px]">1st Quarter</div>
                <div className="font-extrabold text-amber-400 text-sm">20%</div>
              </div>
              <div className="p-2 bg-slate-900 rounded-lg">
                <div className="text-slate-400 text-[11px]">Halftime</div>
                <div className="font-extrabold text-amber-400 text-sm">30%</div>
              </div>
              <div className="p-2 bg-slate-900 rounded-lg">
                <div className="text-slate-400 text-[11px]">3rd Quarter</div>
                <div className="font-extrabold text-amber-400 text-sm">20%</div>
              </div>
              <div className="p-2 bg-slate-900 rounded-lg">
                <div className="text-slate-400 text-[11px]">Final Score</div>
                <div className="font-extrabold text-amber-400 text-sm">30%</div>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl cursor-pointer transition-colors shadow-md"
          >
            Got It, Let's Play!
          </button>
        </div>
      </div>
    </div>
  );
};
