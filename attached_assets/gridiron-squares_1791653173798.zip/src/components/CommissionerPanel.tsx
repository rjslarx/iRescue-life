import React, { useState } from 'react';
import { Square, PoolSettings, GameScores, QuarterWinner } from '../types/pool';
import {
  ShieldAlert,
  CheckCircle,
  XCircle,
  Dices,
  Lock,
  Unlock,
  Settings,
  Trophy,
  DollarSign,
  Users,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import { shuffleDigits } from '../utils/sampleData';
import { playWinnerFanfare } from '../utils/soundEffects';

interface CommissionerPanelProps {
  settings: PoolSettings;
  onUpdateSettings: (settings: PoolSettings) => void;
  squares: Square[];
  onApprovePayment: (squareId: number) => void;
  onDeclinePayment: (squareId: number) => void;
  scores: GameScores;
  onUpdateScores: (scores: GameScores) => void;
  winners: QuarterWinner[];
  onResetToSample: () => void;
  onResetToEmpty: () => void;
  onClose: () => void;
}

export const CommissionerPanel: React.FC<CommissionerPanelProps> = ({
  settings,
  onUpdateSettings,
  squares,
  onApprovePayment,
  onDeclinePayment,
  scores,
  onUpdateScores,
  winners,
  onResetToSample,
  onResetToEmpty,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'queue' | 'scores' | 'axis' | 'settings'>('queue');
  
  // Pending verification squares
  const pendingSquares = squares.filter((s) => s.status === 'pending_verification');
  const confirmedSquares = squares.filter((s) => s.status === 'confirmed');

  const totalPot = settings.squarePrice * 100;
  const collectedPot = confirmedSquares.length * settings.squarePrice;
  const pendingPot = pendingSquares.length * settings.squarePrice;

  // Handle randomizing digits
  const handleRandomizeDigits = () => {
    if (confirm('Randomize both Home and Away axis digits (0 to 9)? This will shuffle numbers for fair play.')) {
      const newRows = shuffleDigits();
      const newCols = shuffleDigits();
      onUpdateSettings({
        ...settings,
        rowNumbers: newRows,
        colNumbers: newCols,
        numbersLocked: true,
      });
    }
  };

  const handleToggleLock = () => {
    onUpdateSettings({
      ...settings,
      numbersLocked: !settings.numbersLocked,
    });
  };

  const handleScoreChange = (
    quarter: 'q1' | 'q2' | 'q3' | 'q4',
    team: 'home' | 'away',
    val: string
  ) => {
    const num = val === '' ? null : Math.max(0, parseInt(val, 10) || 0);
    onUpdateScores({
      ...scores,
      [quarter]: {
        ...scores[quarter],
        [team]: num,
        isComplete: scores[quarter].isComplete,
      },
    });
  };

  const handleToggleQuarterComplete = (quarter: 'q1' | 'q2' | 'q3' | 'q4') => {
    const nextState = !scores[quarter].isComplete;
    if (nextState) {
      playWinnerFanfare();
    }
    onUpdateScores({
      ...scores,
      [quarter]: {
        ...scores[quarter],
        isComplete: nextState,
      },
    });
  };

  const handleFillDemoScores = () => {
    playWinnerFanfare();
    onUpdateScores({
      q1: { home: 7, away: 3, isComplete: true },
      q2: { home: 14, away: 10, isComplete: true },
      q3: { home: 21, away: 17, isComplete: true },
      q4: { home: 28, away: 24, isComplete: true },
      currentQuarter: 'final',
    });
  };

  return (
    <div className="bg-[#0A101D] border-b border-amber-500/30 py-6 px-4 sm:px-6 lg:px-8 shadow-2xl relative animate-in slide-in-from-top-4 duration-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-md shadow-amber-500/20">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-white">
                  Commissioner Control Panel
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Manager Mode
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Review payment verifications, manage axis numbers, update quarter scores, and customize pool settings.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer"
          >
            Exit Manager Mode
          </button>
        </div>

        {/* Quick KPI Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 my-5">
          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
            <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
              <span>Verified Pot</span>
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-xl font-black text-emerald-400 font-mono-num">
              ${collectedPot.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-500">
              {confirmedSquares.length} squares confirmed
            </div>
          </div>

          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
            <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
              <span>Pending Review</span>
              <Users className="w-3.5 h-3.5 text-blue-400" />
            </div>
            <div className="text-xl font-black text-blue-400 font-mono-num">
              ${pendingPot.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-500">
              {pendingSquares.length} payments to verify
            </div>
          </div>

          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3">
            <div className="text-[11px] text-slate-400 mb-1 flex items-center justify-between">
              <span>Total Board Value</span>
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-xl font-black text-white font-mono-num">
              ${totalPot.toLocaleString()}
            </div>
            <div className="text-[10px] text-slate-500">
              100 squares × ${settings.squarePrice}
            </div>
          </div>

          <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 flex flex-col justify-between">
            <div className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Axis Digits Status</span>
              {settings.numbersLocked ? (
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
              ) : (
                <Unlock className="w-3.5 h-3.5 text-amber-400" />
              )}
            </div>
            <div className="text-sm font-bold text-slate-200">
              {settings.numbersLocked ? 'Locked (0-9 Visible)' : 'Hidden (Blind Picking)'}
            </div>
            <div className="text-[10px] text-slate-500">
              Home & Away Axes
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 gap-2 mb-6 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('queue')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${
              activeTab === 'queue'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Payment Verification Queue</span>
            {pendingSquares.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-bold">
                {pendingSquares.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('scores')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'scores'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>Live Quarter Scores & Winners</span>
          </button>

          <button
            onClick={() => setActiveTab('axis')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'axis'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Dices className="w-3.5 h-3.5" />
            <span>Axis Digits Randomizer</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`pb-2.5 px-3 border-b-2 transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'settings'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Pool Rules & Handles</span>
          </button>
        </div>

        {/* TAB 1: VERIFICATION QUEUE */}
        {activeTab === 'queue' && (
          <div className="space-y-4">
            {pendingSquares.length === 0 ? (
              <div className="p-8 text-center bg-slate-950/50 border border-slate-800 rounded-2xl">
                <CheckCircle className="w-10 h-10 text-emerald-400 mx-auto mb-2 opacity-80" />
                <h4 className="text-sm font-bold text-white mb-1">
                  All Payments Verified!
                </h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  There are no pending square claims awaiting approval. When participants click "I've Sent Payment", their submissions will appear here for verification.
                </p>
              </div>
            ) : (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-lg">
                <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span className="font-semibold text-slate-200">
                    Pending Claims Requiring Commissioner Check ({pendingSquares.length})
                  </span>
                  <span>Cross-check with your Venmo / Cash App history</span>
                </div>
                <div className="divide-y divide-slate-800/80">
                  {pendingSquares.map((sq) => (
                    <div
                      key={sq.id}
                      className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:bg-slate-900/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-800 flex items-center justify-center font-mono-num font-black text-blue-300 shrink-0">
                          #{sq.id < 10 ? `0${sq.id}` : sq.id}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">
                              {sq.ownerName}
                            </span>
                            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                              sq.paymentMethod === 'venmo'
                                ? 'bg-[#008CFF]/20 text-[#008CFF] border border-[#008CFF]/40'
                                : 'bg-[#00D632]/20 text-[#00D632] border border-[#00D632]/40'
                            }`}>
                              {sq.paymentMethod}
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5 flex flex-wrap items-center gap-2">
                            <span>Amount: <strong className="text-emerald-400 font-mono-num">${settings.squarePrice}.00</strong></span>
                            {sq.ownerContact && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span>{sq.ownerContact}</span>
                              </>
                            )}
                          </div>
                          {sq.paymentNote && (
                            <div className="text-[11px] text-amber-200/90 font-mono-num mt-1 bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/30">
                              Memo: {sq.paymentNote}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Approval Buttons */}
                      <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
                        <button
                          onClick={() => onApprovePayment(sq.id)}
                          className="grow sm:grow-0 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-emerald-600/20"
                        >
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Approve & Lock</span>
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Decline and release Square #${sq.id}?`)) {
                              onDeclinePayment(sq.id);
                            }
                          }}
                          className="px-3 py-2 bg-red-950/80 hover:bg-red-900 border border-red-800 text-red-200 font-bold rounded-lg text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Decline</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: LIVE QUARTER SCORES & WINNERS */}
        {activeTab === 'scores' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-bold text-white">
                  Live Quarter Scoreboard & Winner Calculation
                </h4>
                <p className="text-xs text-slate-400">
                  Enter final score for each quarter. The system determines the winning square based on the last digit of each team's score.
                </p>
              </div>
              <button
                onClick={handleFillDemoScores}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Simulate Completed Game Scores</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {(['q1', 'q2', 'q3', 'q4'] as const).map((q) => {
                const label = {
                  q1: '1st Quarter',
                  q2: '2nd Quarter (Halftime)',
                  q3: '3rd Quarter',
                  q4: '4th Quarter / Final',
                }[q];
                const pct = settings.payoutPercentages[q];
                const prize = (totalPot * pct) / 100;
                const qScore = scores[q];
                const qWinner = winners.find((w) => w.quarter === q);

                return (
                  <div
                    key={q}
                    className={`bg-slate-950 border rounded-2xl p-4 flex flex-col justify-between ${
                      qScore.isComplete
                        ? 'border-amber-500/50 shadow-lg shadow-amber-500/10'
                        : 'border-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between pb-2 border-b border-slate-800/80 mb-3 text-xs">
                        <span className="font-extrabold text-white">{label}</span>
                        <span className="font-bold text-amber-400 font-mono-num">
                          ${prize.toFixed(0)} ({pct}%)
                        </span>
                      </div>

                      {/* Inputs */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between gap-2">
                          <label className="text-xs text-slate-400 font-semibold truncate">
                            {settings.homeTeam.short} (Row):
                          </label>
                          <input
                            type="number"
                            min="0"
                            placeholder="0"
                            value={qScore.home ?? ''}
                            onChange={(e) => handleScoreChange(q, 'home', e.target.value)}
                            className="w-16 px-2 py-1 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white font-mono-num text-center focus:outline-none focus:border-amber-400"
                          />
                        </div>

                        <div className="flex items-center justify-between gap-2">
                          <label className="text-xs text-slate-400 font-semibold truncate">
                            {settings.awayTeam.short} (Col):
                          </label>
                          <input
                            type="number"
                            min="0"
                            placeholder="0"
                            value={qScore.away ?? ''}
                            onChange={(e) => handleScoreChange(q, 'away', e.target.value)}
                            className="w-16 px-2 py-1 text-sm bg-slate-900 border border-slate-700 rounded-lg text-white font-mono-num text-center focus:outline-none focus:border-amber-400"
                          />
                        </div>
                      </div>

                      {/* Winner highlight */}
                      {qScore.home !== null && qScore.away !== null && settings.numbersLocked && (
                        <div className="mt-3 p-2 bg-slate-900/90 rounded-lg text-xs space-y-1">
                          <div className="text-[11px] text-slate-400 flex items-center justify-between">
                            <span>Winning Digits:</span>
                            <span className="font-mono-num font-bold text-amber-400">
                              {qScore.home % 10} - {qScore.away % 10}
                            </span>
                          </div>
                          {qWinner ? (
                            <div className="text-white font-bold truncate flex items-center gap-1">
                              <Trophy className="w-3 h-3 text-amber-400 shrink-0" />
                              <span>{qWinner.winnerName} (#{qWinner.squareId})</span>
                            </div>
                          ) : (
                            <div className="text-slate-500 italic text-[11px]">
                              Square Unclaimed
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Quarter Complete checkbox button */}
                    <button
                      onClick={() => handleToggleQuarterComplete(q)}
                      className={`mt-4 w-full py-1.5 px-3 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                        qScore.isComplete
                          ? 'bg-amber-500 text-slate-950 hover:bg-amber-400'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                      }`}
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>{qScore.isComplete ? 'Quarter Official' : 'Mark as Final'}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: AXIS RANDOMIZER */}
        {activeTab === 'axis' && (
          <div className="space-y-6">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Dices className="w-4 h-4 text-amber-400" />
                    <span>Fair-Play Digit Randomization (0 to 9)</span>
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 max-w-xl">
                    Standard pool rules dictate that participants pick squares blindly without knowing the row and column numbers. Once all squares are sold (or right before kickoff), randomize and lock numbers.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRandomizeDigits}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-2 shadow-lg shadow-amber-500/20"
                  >
                    <Dices className="w-4 h-4" />
                    <span>Randomize Digits (0-9)</span>
                  </button>

                  <button
                    onClick={handleToggleLock}
                    className={`px-3 py-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer flex items-center gap-1.5 ${
                      settings.numbersLocked
                        ? 'bg-emerald-950/60 border-emerald-700 text-emerald-300'
                        : 'bg-amber-950/60 border-amber-700 text-amber-300'
                    }`}
                  >
                    {settings.numbersLocked ? (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        <span>Locked</span>
                      </>
                    ) : (
                      <>
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Hidden</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Display current axis sequences */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-800">
                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <div className="text-xs font-bold text-white mb-2 flex items-center justify-between">
                    <span>{settings.homeTeam.name} (Row Numbers):</span>
                    <span className="text-[11px] text-slate-400">Rows 1-10</span>
                  </div>
                  <div className="flex gap-1.5 overflow-x-auto py-1">
                    {settings.rowNumbers.map((num, i) => (
                      <div
                        key={`row-digit-${i}`}
                        className="w-8 h-8 rounded-lg bg-slate-950 border border-slate-700 flex items-center justify-center font-mono-num font-bold text-amber-400 text-sm shrink-0"
                      >
                        {settings.numbersLocked ? num : '?'}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-900/80 p-3.5 rounded-xl border border-slate-800">
                  <div className="text-xs font-bold text-white mb-2 flex items-center justify-between">
                    <span>{settings.awayTeam.name} (Column Numbers):</span>
                    <span className="text-[11px] text-slate-400">Cols 1-10</span>
                  </div>
                  <div className="flex gap-1.5 overflow-x-auto py-1">
                    {settings.colNumbers.map((num, i) => (
                      <div
                        key={`col-digit-${i}`}
                        className="w-8 h-8 rounded-lg bg-slate-950 border border-slate-700 flex items-center justify-center font-mono-num font-bold text-amber-400 text-sm shrink-0"
                      >
                        {settings.numbersLocked ? num : '?'}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: SETTINGS & HANDLES */}
        {activeTab === 'settings' && (
          <div className="space-y-6">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-5">
              <h4 className="text-sm font-bold text-white">
                Payment Handles, Pricing & Matchup Configuration
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                {/* Square Price */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Square Price ($ USD)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={settings.squarePrice}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        squarePrice: Math.max(1, parseInt(e.target.value, 10) || 10),
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono-num focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Total Pot: ${(settings.squarePrice * 100).toLocaleString()}
                  </span>
                </div>

                {/* Venmo Handle */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Commissioner Venmo Handle
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">@</span>
                    <input
                      type="text"
                      value={settings.venmoHandle.replace(/^@/, '')}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          venmoHandle: e.target.value.replace(/^@/, ''),
                        })
                      }
                      className="w-full pl-7 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono-num focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Pre-filled in player checkout QR & links
                  </span>
                </div>

                {/* Cash App Handle */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Commissioner Cash App Cashtag
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
                    <input
                      type="text"
                      value={settings.cashAppHandle.replace(/^\$/, '')}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          cashAppHandle: e.target.value.replace(/^\$/, ''),
                        })
                      }
                      className="w-full pl-7 pr-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono-num focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    Generates Cash.app deep links
                  </span>
                </div>

                {/* Home Team Name */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Home Team Name
                  </label>
                  <input
                    type="text"
                    value={settings.homeTeam.name}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        homeTeam: { ...settings.homeTeam, name: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Away Team Name */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Away Team Name
                  </label>
                  <input
                    type="text"
                    value={settings.awayTeam.name}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        awayTeam: { ...settings.awayTeam, name: e.target.value },
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                {/* Event Title */}
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Pool Display Title
                  </label>
                  <input
                    type="text"
                    value={settings.poolName}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        poolName: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Danger Zone / Reset buttons */}
              <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
                <span className="text-slate-400">Board Presets & Testing:</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      if (confirm('Reset to loaded Super Bowl demo pool with 72 claimed squares?')) {
                        onResetToSample();
                      }
                    }}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Load Demo Pool</span>
                  </button>

                  <button
                    onClick={() => {
                      if (confirm('Clear all 100 squares back to empty available state? This will erase all player claims.')) {
                        onResetToEmpty();
                      }
                    }}
                    className="px-3 py-1.5 bg-red-950/60 hover:bg-red-900 text-red-200 border border-red-800/80 rounded-lg font-semibold transition-colors cursor-pointer"
                  >
                    Clear All 100 Squares
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
