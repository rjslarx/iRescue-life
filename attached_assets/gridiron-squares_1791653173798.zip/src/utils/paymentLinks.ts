import QRCode from 'qrcode';

export interface PaymentDetails {
  handle: string;
  amount: number;
  note: string;
}

export function cleanHandle(handle: string): string {
  return handle.trim().replace(/^[@$]/, '');
}

/**
 * Generates Venmo mobile app deep link
 * Format: venmo://paycharge?txn=pay&recipients=Handle&amount=10&note=Square%20%2324%20-%20John
 */
export function getVenmoDeepLink({ handle, amount, note }: PaymentDetails): string {
  const clean = cleanHandle(handle);
  const encodedNote = encodeURIComponent(note);
  return `venmo://paycharge?txn=pay&recipients=${clean}&amount=${amount}&note=${encodedNote}`;
}

/**
 * Generates Venmo browser web fallback link
 */
export function getVenmoWebLink({ handle, amount, note }: PaymentDetails): string {
  const clean = cleanHandle(handle);
  const encodedNote = encodeURIComponent(note);
  return `https://venmo.com/${clean}?txn=pay&amount=${amount}&note=${encodedNote}`;
}

/**
 * Generates Cash App payment link
 * Format: https://cash.app/$handle/10
 */
export function getCashAppDeepLink({ handle, amount }: PaymentDetails): string {
  const clean = cleanHandle(handle);
  return `https://cash.app/$${clean}/${amount}`;
}

/**
 * Generates a high-resolution, dark/light contrast QR Code Data URL
 */
export async function generateQrCode(text: string, isCashApp: boolean = false): Promise<string> {
  try {
    const dataUrl = await QRCode.toDataURL(text, {
      width: 320,
      margin: 1,
      color: {
        dark: isCashApp ? '#00D632' : '#008CFF',
        light: '#0F172A',
      },
      errorCorrectionLevel: 'M',
    });
    return dataUrl;
  } catch (err) {
    console.error('Error generating QR code:', err);
    // Fallback simple QR
    return '';
  }
}

/**
 * Clipboard helper that returns a boolean indicating success
 */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      const successful = document.execCommand('copy');
      textArea.remove();
      return successful;
    }
  } catch (err) {
    console.error('Copy failed:', err);
    return false;
  }
}
