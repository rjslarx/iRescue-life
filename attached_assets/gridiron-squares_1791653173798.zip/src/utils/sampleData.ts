import { Square, PoolSettings, GameScores } from '../types/pool';

export const DEFAULT_POOL_SETTINGS: PoolSettings = {
  poolName: 'Super Bowl LIX Championship Squares',
  eventDate: 'Sunday, Feb 9 · 6:30 PM EST',
  squarePrice: 10,
  homeTeam: {
    name: 'Kansas City',
    short: 'KC',
    primaryColor: '#E31837',
    secondaryColor: '#FFB81C',
    city: 'Kansas City',
  },
  awayTeam: {
    name: 'San Francisco',
    short: 'SF',
    primaryColor: '#AA0000',
    secondaryColor: '#B3995D',
    city: 'San Francisco',
  },
  venmoHandle: 'CommishDave',
  cashAppHandle: 'DavePools',
  payoutPercentages: {
    q1: 20,
    q2: 30,
    q3: 20,
    q4: 30,
  },
  numbersLocked: true,
  rowNumbers: [7, 0, 4, 2, 8, 3, 1, 9, 6, 5],
  colNumbers: [3, 7, 0, 8, 1, 4, 9, 2, 5, 6],
  commissionerPin: '1234',
};

export const DEFAULT_SCORES: GameScores = {
  q1: { home: 7, away: 3, isComplete: true },
  q2: { home: 14, away: 10, isComplete: true },
  q3: { home: 21, away: 17, isComplete: false },
  q4: { home: null, away: null, isComplete: false },
  currentQuarter: 'q3',
};

const SAMPLE_PARTICIPANTS = [
  'Marcus T.', 'Sarah J.', 'Coach Dave', 'Tyler H.', 'Amanda B.',
  'Jake Foster', 'Uncle Bob', 'Elena P.', 'Chris O.', 'Jessica M.',
  'Jordan Lee', 'Tony Soprano', 'Sammy K.', 'Rachel Green', 'Danny D.',
  'Big Mike', 'Kayla R.', 'Brandon W.', 'Lauren S.', 'Nick Carter',
  'Pete Higgins', 'Chloe Bennett', 'Gary V.', 'Melissa H.', 'Zack Morris',
  'Brooke Davis', 'Logan Roy', 'Wendy B.', 'Felix K.', 'Megan Fox',
  'Brian Griffin', 'Lucas Scott', 'Haley James', 'Ryan Atwood', 'Seth Cohen',
  'Summer Roberts', 'Marissa Cooper', 'Jim Halpert', 'Pam Beesly', 'Dwight Schrute',
  'Michael Scott', 'Kelly Kapoor', 'Stanley Hudson', 'Phyllis Vance', 'Kevin Malone',
  'Oscar Martinez', 'Angela Martin', 'Andy Bernard', 'Toby Flenderson', 'Creed Bratton',
  'Darryl Philbin', 'Meredith Palmer', 'Jan Levinson', 'David Wallace', 'Roy Anderson',
  'Karen Filippelli', 'Holly Flax', 'Bob Vance', 'Mose Schrute', 'Clark Green',
  'Pete Miller', 'Robert California', 'Nellie Bertram', 'Todd Packer', 'Cathy Simms'
];

export function generateInitialSquares(): Square[] {
  const squares: Square[] = [];
  
  // We'll mark ~68 as confirmed, ~7 as pending verification, 25 as available
  let participantIdx = 0;

  for (let row = 0; row < 10; row++) {
    for (let col = 0; col < 10; col++) {
      const id = row * 10 + col;
      
      // Let's create a curated distribution so there are available squares to buy right away
      const isAvailable = [
        3, 8, 12, 17, 21, 26, 32, 38, 41, 47,
        53, 58, 62, 69, 73, 77, 81, 86, 92, 97,
        15, 35, 55, 75
      ].includes(id);

      const isPending = [5, 23, 44, 60, 84, 95].includes(id);

      if (isAvailable) {
        squares.push({
          id,
          row,
          col,
          status: 'available',
        });
      } else if (isPending) {
        const name = SAMPLE_PARTICIPANTS[participantIdx % SAMPLE_PARTICIPANTS.length];
        participantIdx++;
        const method = id % 2 === 0 ? 'venmo' : 'cashapp';
        squares.push({
          id,
          row,
          col,
          status: 'pending_verification',
          ownerName: name,
          ownerContact: `${name.toLowerCase().replace(/[^a-z]/g, '')}@gmail.com`,
          paymentMethod: method,
          paymentNote: `Square #${id} - ${name}`,
          reservedAt: new Date(Date.now() - (id * 180000)).toISOString(),
        });
      } else {
        const name = SAMPLE_PARTICIPANTS[participantIdx % SAMPLE_PARTICIPANTS.length];
        participantIdx++;
        const method = id % 3 === 0 ? 'cashapp' : 'venmo';
        squares.push({
          id,
          row,
          col,
          status: 'confirmed',
          ownerName: name,
          ownerContact: `${name.toLowerCase().replace(/[^a-z]/g, '')}@gmail.com`,
          paymentMethod: method,
          paymentNote: `Square #${id} - ${name}`,
          paidAt: new Date(Date.now() - (id * 3600000)).toISOString(),
          verifiedAt: new Date(Date.now() - (id * 3500000)).toISOString(),
        });
      }
    }
  }

  return squares;
}

export function generateBlankSquares(): Square[] {
  const squares: Square[] = [];
  for (let row = 0; row < 10; row++) {
    for (let col = 0; col < 10; col++) {
      squares.push({
        id: row * 10 + col,
        row,
        col,
        status: 'available',
      });
    }
  }
  return squares;
}

export function shuffleDigits(): number[] {
  const digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  for (let i = digits.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [digits[i], digits[j]] = [digits[j], digits[i]];
  }
  return digits;
}
