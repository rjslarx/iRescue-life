/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Square,
  PoolSettings,
  GameScores,
  QuarterWinner,
  GridFilter,
  PaymentMethod,
} from './types/pool';
import {
  DEFAULT_POOL_SETTINGS,
  DEFAULT_SCORES,
  generateInitialSquares,
  generateBlankSquares,
} from './utils/sampleData';
import { Navbar } from './components/Navbar';
import { ScoreBanner } from './components/ScoreBanner';
import { FootballGrid } from './components/FootballGrid';
import { SquareModal } from './components/SquareModal';
import { PaymentModal } from './components/PaymentModal';
import { CommissionerPanel } from './components/CommissionerPanel';
import { ScoreboardPayouts } from './components/ScoreboardPayouts';
import { RulesModal } from './components/RulesModal';
import { ShareModal } from './components/ShareModal';
import { Trophy, HelpCircle, ArrowRight, ShieldCheck, Check } from 'lucide-react';
import confetti from 'canvas-confetti';
import stadiumHeroImage from './assets/images/stadium_hero_backdrop_1791652415511.jpg';

export default function App() {
  // Persistence state
  const [settings, setSettings] = useState<PoolSettings>(() => {
    try {
      const saved = localStorage.getItem('gridiron_settings');
      return saved ? JSON.parse(saved) : DEFAULT_POOL_SETTINGS;
    } catch {
      return DEFAULT_POOL_SETTINGS;
    }
  });

  const [squares, setSquares] = useState<Square[]>(() => {
    try {
      const saved = localStorage.getItem('gridiron_squares');
      return saved ? JSON.parse(saved) : generateInitialSquares();
    } catch {
      return generateInitialSquares();
    }
  });

  const [scores, setScores] = useState<GameScores>(() => {
    try {
      const saved = localStorage.getItem('gridiron_scores');
      return saved ? JSON.parse(saved) : DEFAULT_SCORES;
    } catch {
      return DEFAULT_SCORES;
    }
  });

  const [isCommissioner, setIsCommissioner] = useState<boolean>(() => {
    return localStorage.getItem('gridiron_is_commish') === 'true';
  });

  const [currentUser, setCurrentUser] = useState<string>(() => {
    return localStorage.getItem('gridiron_user_name') || '';
  });

  // UI state
  const [filter, setFilter] = useState<GridFilter>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [claimantData, setClaimantData] = useState<{ name: string; contact: string; note: string }>({
    name: '',
    contact: '',
    note: '',
  });

  // Modals
  const [isSquareModalOpen, setIsSquareModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isScoreboardOpen, setIsScoreboardOpen] = useState(false);
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('gridiron_settings', JSON.stringify(settings));
    } catch (e) {
      console.error(e);
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem('gridiron_squares', JSON.stringify(squares));
    } catch (e) {
      console.error(e);
    }
  }, [squares]);

  useEffect(() => {
    try {
      localStorage.setItem('gridiron_scores', JSON.stringify(scores));
    } catch (e) {
      console.error(e);
    }
  }, [scores]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 4000);
  };

  // Derive counts & pot
  const confirmedCount = useMemo(() => squares.filter((s) => s.status === 'confirmed').length, [squares]);
  const pendingCount = useMemo(() => squares.filter((s) => s.status === 'pending_verification').length, [squares]);
  const availableCount = useMemo(() => squares.filter((s) => s.status === 'available').length, [squares]);
  const totalPot = settings.squarePrice * 100;

  // Derive quarter winners based on locked row/col numbers and current quarter scores
  const winners: QuarterWinner[] = useMemo(() => {
    if (!settings.numbersLocked) return [];

    const list: QuarterWinner[] = [];
    const quarters = [
      { key: 'q1' as const, label: '1st Quarter', score: scores.q1, pct: settings.payoutPercentages.q1 },
      { key: 'q2' as const, label: 'Halftime (2nd Qtr)', score: scores.q2, pct: settings.payoutPercentages.q2 },
      { key: 'q3' as const, label: '3rd Quarter', score: scores.q3, pct: settings.payoutPercentages.q3 },
      { key: 'q4' as const, label: 'Final Score', score: scores.q4, pct: settings.payoutPercentages.q4 },
    ];

    quarters.forEach(({ key, label, score, pct }) => {
      if (score.home !== null && score.away !== null) {
        const homeDigit = score.home % 10;
        const awayDigit = score.away % 10;

        const rowIndex = settings.rowNumbers.indexOf(homeDigit);
        const colIndex = settings.colNumbers.indexOf(awayDigit);

        if (rowIndex !== -1 && colIndex !== -1) {
          const squareId = rowIndex * 10 + colIndex;
          const matchedSquare = squares.find((s) => s.id === squareId);
          const payoutAmount = (totalPot * pct) / 100;

          list.push({
            quarter: key,
            label,
            homeDigit,
            awayDigit,
            squareId,
            winnerName: matchedSquare?.ownerName || 'Unsold Square',
            payoutAmount,
            isConfirmed: matchedSquare?.status === 'confirmed',
          });
        }
      }
    });

    return list;
  }, [settings, scores, squares, totalPot]);

  // Click on a square
  const handleSelectSquare = (sq: Square) => {
    setSelectedSquare(sq);
    setIsSquareModalOpen(true);
  };

  // Proceed from selection form to payment checkout
  const handleProceedToPayment = (
    sq: Square,
    data: { name: string; contact: string; note: string }
  ) => {
    setSelectedSquare(sq);
    setClaimantData(data);
    setCurrentUser(data.name);
    setIsSquareModalOpen(false);
    setIsPaymentModalOpen(true);
  };

  // Submit payment confirmation
  const handleSubmitPayment = (
    squareId: number,
    method: PaymentMethod,
    claimant: { name: string; contact: string; note: string; transactionRef: string }
  ) => {
    setSquares((prev) =>
      prev.map((s) => {
        if (s.id === squareId) {
          return {
            ...s,
            status: 'pending_verification',
            ownerName: claimant.name,
            ownerContact: claimant.contact,
            paymentMethod: method,
            paymentNote: claimant.transactionRef || claimant.note || `Square #${squareId} - ${claimant.name}`,
            reservedAt: new Date().toISOString(),
          };
        }
        return s;
      })
    );

    confetti({
      particleCount: 60,
      spread: 60,
      origin: { y: 0.7 },
      colors: method === 'venmo' ? ['#008CFF', '#FFFFFF'] : ['#00D632', '#FFFFFF'],
    });

    showToast(
      `Square #${squareId} payment submitted! Awaiting commissioner verification.`
    );
  };

  // Commissioner Actions
  const handleApprovePayment = (squareId: number) => {
    setSquares((prev) =>
      prev.map((s) => {
        if (s.id === squareId) {
          return {
            ...s,
            status: 'confirmed',
            verifiedAt: new Date().toISOString(),
          };
        }
        return s;
      })
    );
    showToast(`Square #${squareId} payment verified & confirmed!`);
  };

  const handleDeclinePayment = (squareId: number) => {
    setSquares((prev) =>
      prev.map((s) => {
        if (s.id === squareId) {
          return {
            id: s.id,
            row: s.row,
            col: s.col,
            status: 'available',
          };
        }
        return s;
      })
    );
    showToast(`Square #${squareId} released back to available.`);
  };

  const handleResetToSample = () => {
    setSquares(generateInitialSquares());
    setSettings(DEFAULT_POOL_SETTINGS);
    setScores(DEFAULT_SCORES);
    showToast('Reset to default Super Bowl demo pool with 72 claimed squares.');
  };

  const handleResetToEmpty = () => {
    setSquares(generateBlankSquares());
    showToast('All 100 squares reset to empty available state.');
  };

  const handleToggleCommissioner = () => {
    const nextState = !isCommissioner;
    setIsCommissioner(nextState);
    localStorage.setItem('gridiron_is_commish', String(nextState));
    if (nextState) {
      showToast('Commissioner mode active: review payments, manage digits & scores');
    }
  };

  const handleQuickClaimFirstAvailable = () => {
    const first = squares.find((s) => s.status === 'available');
    if (first) {
      handleSelectSquare(first);
    } else {
      showToast('All 100 squares are claimed! Check the scoreboard.');
    }
  };

  return (
    <div className="min-h-screen bg-[#080D15] text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      
      {/* Toast notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300">
          <div className="bg-slate-900 border border-amber-500/50 text-white px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-3 text-xs max-w-sm">
            <div className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center shrink-0">
              <Check className="w-3.5 h-3.5 stroke-[3]" />
            </div>
            <span className="font-medium text-slate-200">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        poolName={settings.poolName}
        isCommissioner={isCommissioner}
        onToggleCommissioner={handleToggleCommissioner}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenShare={() => setIsShareOpen(true)}
        onOpenWinners={() => setIsScoreboardOpen(true)}
        pendingCount={pendingCount}
      />

      {/* Hero Section with Stadium Image Banner */}
      <section className="relative overflow-hidden border-b border-slate-800">
        <div className="absolute inset-0 z-0">
          <img
            src={stadiumHeroImage}
            alt="Football Stadium Field at Night"
            className="w-full h-full object-cover object-center filter brightness-[0.38] contrast-125"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#080D15] via-[#080D15]/60 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <div className="max-w-3xl">
            {/* Metadata unboxed text discipline */}
            <div className="flex items-center gap-2 text-xs text-amber-400 font-semibold mb-3 tracking-wider uppercase">
              <span>10x10 Football Squares Pool</span>
              <span aria-hidden="true">·</span>
              <span>100 Squares</span>
              <span aria-hidden="true">·</span>
              <span>${settings.squarePrice} / Square</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-400">${totalPot.toLocaleString()} Total Pot</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight leading-tight mb-4 text-balance">
              Select Your Square. Pay Instantly via Venmo & Cash App.
            </h1>

            <p className="text-base text-slate-300 leading-relaxed mb-6 max-w-2xl">
              Claim squares for the big game with real-time deep links, automated payment memos, and scannable QR codes. Follow along with live quarter scores and automatic cash prize payouts.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={handleQuickClaimFirstAvailable}
                className="px-5 py-3 bg-amber-500 hover:bg-amber-400 active:scale-[0.99] text-slate-950 font-black text-sm rounded-xl transition-all shadow-xl shadow-amber-500/20 flex items-center gap-2 cursor-pointer"
              >
                <span>Pick an Available Square (${settings.squarePrice})</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsScoreboardOpen(true)}
                className="px-4 py-3 bg-slate-900/90 hover:bg-slate-800 text-white font-bold text-sm rounded-xl border border-slate-700 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Trophy className="w-4 h-4 text-amber-400" />
                <span>Quarter Winners & Payouts</span>
              </button>

              <button
                onClick={() => setIsRulesOpen(true)}
                className="px-4 py-3 bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white font-medium text-sm rounded-xl border border-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <HelpCircle className="w-4 h-4 text-slate-400" />
                <span>How to Play</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Live Matchup & Scoreboard Banner */}
      <ScoreBanner
        settings={settings}
        scores={scores}
        confirmedCount={confirmedCount}
        pendingCount={pendingCount}
        availableCount={availableCount}
        totalPot={totalPot}
        onOpenScoreboard={() => setIsScoreboardOpen(true)}
        onQuickClaim={handleQuickClaimFirstAvailable}
      />

      {/* Commissioner Panel (When active) */}
      {isCommissioner && (
        <CommissionerPanel
          settings={settings}
          onUpdateSettings={setSettings}
          squares={squares}
          onApprovePayment={handleApprovePayment}
          onDeclinePayment={handleDeclinePayment}
          scores={scores}
          onUpdateScores={setScores}
          winners={winners}
          onResetToSample={handleResetToSample}
          onResetToEmpty={handleResetToEmpty}
          onClose={() => setIsCommissioner(false)}
        />
      )}

      {/* The 10x10 Football Grid */}
      <main className="grow">
        <FootballGrid
          squares={squares}
          settings={settings}
          winners={winners}
          filter={filter}
          onFilterChange={setFilter}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          currentUser={currentUser}
          onSelectSquare={handleSelectSquare}
        />
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800 bg-[#090D16] py-8 px-4 sm:px-6 lg:px-8 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-white">GRIDIRON SQUARES</span>
            <span aria-hidden="true">·</span>
            <span>Peer-to-Peer Football Pool Manager</span>
            <span aria-hidden="true">·</span>
            <span className="text-slate-400">Venmo & Cash App Ready</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => setIsRulesOpen(true)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Rules & Coordinates
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsScoreboardOpen(true)}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Quarter Payouts
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={handleToggleCommissioner}
              className="hover:text-amber-400 transition-colors cursor-pointer flex items-center gap-1"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{isCommissioner ? 'Manager Active' : 'Commissioner Mode'}</span>
            </button>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      {/* 1. Square Detail & Claimant Modal */}
      <SquareModal
        square={selectedSquare}
        settings={settings}
        isOpen={isSquareModalOpen}
        onClose={() => setIsSquareModalOpen(false)}
        onProceedToPayment={handleProceedToPayment}
        isCommissioner={isCommissioner}
        onApproveSquare={handleApprovePayment}
        onReleaseSquare={handleDeclinePayment}
        quarterWinners={winners}
      />

      {/* 2. Venmo & Cash App QR Checkout Modal */}
      <PaymentModal
        square={selectedSquare}
        settings={settings}
        isOpen={isPaymentModalOpen}
        claimantData={claimantData}
        onClose={() => setIsPaymentModalOpen(false)}
        onSubmitPayment={handleSubmitPayment}
      />

      {/* 3. Scoreboard Payouts & Quarter Winners Log */}
      <ScoreboardPayouts
        settings={settings}
        scores={scores}
        winners={winners}
        isOpen={isScoreboardOpen}
        onClose={() => setIsScoreboardOpen(false)}
        onSelectWinnerSquare={(id) => {
          const sq = squares.find((s) => s.id === id);
          if (sq) handleSelectSquare(sq);
        }}
      />

      {/* 4. Rules & How Football Squares Work */}
      <RulesModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
        squarePrice={settings.squarePrice}
      />

      {/* 5. Invite Friends Share Modal */}
      <ShareModal
        isOpen={isShareOpen}
        onClose={() => setIsShareOpen(false)}
        poolName={settings.poolName}
        squarePrice={settings.squarePrice}
        availableCount={availableCount}
      />

    </div>
  );
}
