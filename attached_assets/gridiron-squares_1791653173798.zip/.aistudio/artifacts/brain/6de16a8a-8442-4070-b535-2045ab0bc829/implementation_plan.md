# Gridiron Squares: Football Pool & Payment Hub

A modern, responsive football squares pool application where players select squares on a 10x10 board, pay seamlessly via pre-filled Venmo and Cash App deep links or QR codes, and follow game-day quarter scores with automatic winner calculation and payout ledgers.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following product specifications were confirmed during the interactive clarification interview:

- **Confirmed Grid Format**: Standard 10x10 grid containing 100 squares, with row and column numbers (0–9) for the home and away teams.
- **Confirmed Payment Mechanism**: Pre-filled deep links (`venmo://paycharge`, `https://cash.app/$...`) and dynamic QR codes tailored with commissioner handles, square price, and auto-generated payment memo references (e.g., `Square #42 - Alex M`), paired with a commissioner verification queue (`Pending Verification` -> `Paid & Confirmed`).
- **Confirmed Scoring & Payouts**: Live quarter score tracker (Q1, Halftime, Q3, Final) with instant determination of winning square coordinates based on the last digit of each team's score, quarter payout percentages, and animated board spotlighting.

---

## 1. Overview & Core Concept

- **What It Does**: Gridiron Squares provides a complete digital experience for managing and participating in football squares pools. Players can view the live board, select available squares, enter their participant details, and instantly pay the commissioner via Venmo or Cash App. Commissioners can set prices, customize team names, randomize or reveal axis digits (0–9), verify incoming payments, update live quarter scores, and automatically highlight winning squares with dollar payouts.
- **Target Audience / Persona**: Game-day hosts, office pool organizers, alumni clubs, sports bar groups, and football fans hosting Super Bowl or playoff pool parties.
- **Key Value**: Replaces paper posters and messy text chains with an interactive, mobile-friendly board that eliminates payment chasing with automated memos, instant QR codes, and unambiguous rule and winner calculation.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Player Square Selection Flow**:
   - Player lands on the pool overview showing current teams (e.g., Kansas City vs. San Francisco), square price (e.g., $10 / square), remaining open squares, and total pot.
   - Player taps any open square on the 10x10 grid. The cell highlights with crosshair guides along the row and column axes.
   - A drawer/modal opens with square number, team coordinates (if digits revealed), and player entry form (Name, Contact Email/Phone, Note).
   - Player confirms selection, shifting the square state to `Reserved (Awaiting Payment)`.

2. **Payment & QR Code Checkout Flow**:
   - Checkout modal presents payment options:
     - **Venmo**: Displays pre-formatted Venmo deep link button (`venmo://paycharge?txn=pay&recipients=...&amount=...&note=...`) and direct web fallback (`venmo.com`), plus a scannable QR code and 1-click handle/memo copy buttons.
     - **Cash App**: Displays pre-formatted Cash App link (`https://cash.app/$cashtag/...`) and QR code with pre-filled dollar amount and memo.
   - Player clicks "I've Sent the Payment" or provides optional transaction screenshot/ref note. Square status updates to `Payment Submitted (Pending Review)`.

3. **Commissioner Verification & Management Flow**:
   - Commissioner toggles into "Commissioner Mode" (PIN-protected or instant manager view).
   - Commissioner accesses the **Payment Verification Ledger**: a filtered queue of squares categorized by `Paid`, `Pending Verification`, and `Available`.
   - 1-click "Confirm Payment" button validates the player's square and locks their cell in active `Confirmed` state with their display badge.
   - Ability to edit game details (Team 1, Team 2, Date, Square Price, Payout Split: e.g., 20% Q1, 30% Halftime, 20% Q3, 30% Final).
   - "Randomize & Lock Numbers" action: shuffles 0–9 across the top and side headers once pool is full or kickoff begins.

4. **Game Day & Live Quarter Score Tracker**:
   - Floating or dedicated scoreboard bar allows real-time quarter score entry:
     - Q1 Score -> Computes winning digits (e.g., Team A 7, Team B 3 -> Square at Row 7, Col 3) -> Displays winner name and payout amount.
     - Q2 (Halftime), Q3, and Final Score updates.
   - On the 10x10 board, winning squares illuminate with golden winner badges and quarter trophies, leaving a clear historical track of all prize distributions.

### Visual Identity & Theme

- **Aesthetic Direction**: Stadium athletic precision meets modern fintech clarity. High-contrast turf dark slate backdrop (`#0B131E`), subtle chalk line borders (`#1E293B` / `#334155`), athletic gold (`#EAB308` / `#F59E0B`) and turf emerald accents (`#10B981`), with crisp typography.
- **Color Palette & Discipline (60-30-10)**:
  - *60% Dominant Canvas*: Deep stadium slate `#090D16` and dark turf navy `#0F172A`.
  - *30% Structural Surfaces*: High-contrast card surfaces (`#1E293B`), chalk dividers (`rgba(255,255,255,0.08)`), and white text readability.
  - *10% Action & Focal Points*: Venmo electric blue (`#008CFF`), Cash App bright emerald (`#00D632`), and trophy gold (`#F59E0B`) for winning squares.
- **Typography**:
  - *Brand & Scoreboard Display*: `Plus Jakarta Sans` / `Outfit` bold weights for bold athletic scoreboards and section headers.
  - *Grid Coordinates & Amounts*: `JetBrains Mono` / `Space Mono` with `tabular-nums` for precise alignment of digits 0–9, dollar amounts, and square IDs.
- **Zero-Pill & Clean Metadata Discipline**: Clean, unboxed text headers with typographic dot separators (`10x10 Grid · $10 / Square · $1,000 Total Pot`). No clunky badge clutter or artificial telemetry banners.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Peer-to-Peer Deep Links & QR Codes vs. Private Merchant APIs**:
  - *Chosen Approach*: Generate standard RFC deep links (`venmo://paycharge`, `https://venmo.com/...`, `https://cash.app/$handle/amount`) and generate client-rendered high-contrast QR codes with strict copyable memos.
  - *Why*: Venmo and Cash App do not provide open, zero-fee consumer APIs for casual sports pools without commercial merchant agreements and percentage fees. Deep links and scannable QR codes allow instant zero-fee transfers between friends and pool organizers.
  - *Alternatives Considered*: Manual copy-paste text instructions (too tedious, prone to wrong amounts and missing memos).
- **Decision 2: Two-Phase Coordinate Reveal (Fair Play Standards)**:
  - *Chosen Approach*: Numbers along the top (Away) and left (Home) axes remain hidden (`?`) until the pool is filled or the commissioner clicks "Randomize & Lock Axis Digits", ensuring early pickers cannot cherry-pick favored numbers (0, 7, 3).
  - *Why*: Standard national football pool rules mandate blind picking for fair participation.
- **Decision 3: Local Storage Persistence & Multi-State Seed Presets**:
  - *Chosen Approach*: Comprehensive `localStorage` state management with quick sample data seeding (e.g., pre-filled realistic Super Bowl pool with 72 squares claimed, 28 open, with mock pending and confirmed payments) so users can immediately test the board, payment links, and score tracker right out of the box.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Gridiron Squares System                         │
├────────────────────────────────┬───────────────────────────────────────┤
│          Player View           │          Commissioner View            │
│  - 10x10 Interactive Grid      │  - Payment Verification Ledger        │
│  - Row/Col Coordinate Guides   │  - Axis Numbers Randomizer/Lock       │
│  - Square Reservation Modal    │  - Game & Prize Rule Settings         │
│  - Venmo / Cash App QR Checkout│  - Live Score Entry & Simulator       │
└────────────────────────────────┴───────────────────────────────────────┘
                                 │
                                 ▼
┌────────────────────────────────────────────────────────────────────────┐
│                      State Store & Pool Engine                         │
│  - 100 Squares (ID: 00..99, Owner, Status, PaymentType, Timestamp)    │
│  - Axis Headers (Home Digits 0..9, Away Digits 0..9, isLocked)        │
│  - Game Scores (Q1, Q2, Q3, Final, CurrentQuarter)                     │
│  - Payout Calculator (Pot: 100 * Price, Splits: 20/30/20/30%)          │
│  - Storage Adapter: localStorage with Export / Import JSON & Demo Seed │
└────────────────────────────────────────────────────────────────────────┘
                                 │
                                 ▼
┌────────────────────────────────────────────────────────────────────────┐
│                     Payment & Link Generator                           │
│  - Venmo Deep Link & Web Fallback Builder                              │
│  - Cash App Direct Pay URL Builder                                     │
│  - SVG QR Code Renderer for on-screen mobile scanning                  │
│  - 1-Click Clipboard Memo Utilities                                    │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Model Entities

```typescript
type SquareStatus = 'available' | 'reserved' | 'pending_verification' | 'confirmed';

interface Square {
  id: number; // 0 to 99
  row: number; // 0 to 9
  col: number; // 0 to 9
  status: SquareStatus;
  ownerName?: string;
  ownerContact?: string;
  paymentMethod?: 'venmo' | 'cashapp';
  paymentNote?: string;
  paidAt?: string;
  isQuarterWinner?: {
    q1?: boolean;
    q2?: boolean;
    q3?: boolean;
    q4?: boolean;
  };
}

interface PoolSettings {
  poolName: string;
  squarePrice: number;
  homeTeam: { name: string; short: string; color: string };
  awayTeam: { name: string; short: string; color: string };
  venmoHandle: string;
  cashAppHandle: string;
  payoutPercentages: { q1: number; q2: number; q3: number; q4: number };
  numbersLocked: boolean;
  rowNumbers: number[]; // 0..9
  colNumbers: number[]; // 0..9
}

interface GameScores {
  q1: { home: number | null; away: number | null };
  q2: { home: number | null; away: number | null };
  q3: { home: number | null; away: number | null };
  q4: { home: number | null; away: number | null };
  currentQuarter: 1 | 2 | 3 | 4 | 'final' | 'pregame';
}
```

### Interactive Component & State Mapping

1. **Header & Matchup Bar**:
   - Live countdown/game status, total prize pot calculation (`$price * 100`), squares sold counter, and quick view toggles (`All Squares`, `My Squares`, `Winners Only`).
2. **Interactive 10x10 Grid (`FootballGrid`)**:
   - 10 rows $\times$ 10 columns grid with sticky or header axis tags for Home and Away teams.
   - Hover crosshair highlighting active row and column headers.
   - Visual states: Empty (`bg-slate-900/50 hover:bg-slate-800`), Reserved (`border-amber-500/50`), Confirmed (`bg-slate-800 font-semibold`), Quarter Winner (`bg-amber-500/20 ring-2 ring-amber-400 animate-pulse`).
   - Click triggers `SelectSquareModal`.
3. **Payment & QR Checkout Modal (`PaymentCheckoutModal`)**:
   - Segmented toggle between **Venmo** and **Cash App**.
   - Displays real-time generated QR code that links directly to the app or payment profile.
   - Pre-formatted "Pay with Venmo" and "Pay with Cash App" buttons opening native app schemes or fallback URLs.
   - Pre-filled memo generator (e.g., `Square #42 - Alex M`) with single-tap "Copy Note" button.
   - Submission button to notify commissioner.
4. **Commissioner Control Center (`CommissionerPanel`)**:
   - Verification queue with badge count of pending payments.
   - "Approve" and "Decline/Release" square actions.
   - "Randomize Axis Numbers" button (with safety confirmation dialog).
   - Live quarter score inputs with immediate winner evaluation and instant board updates.
   - Customizer for square price, payment handles, and payout splits.
5. **Scoreboard & Payouts Panel (`ScoreboardPayouts`)**:
   - Quarter-by-quarter breakdown of scores, winning digits, winner names, and calculated cash prize payouts.
